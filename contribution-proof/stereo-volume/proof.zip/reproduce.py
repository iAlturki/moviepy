"""Reproduce the stereo-volume failure using generated tones, not personal audio."""
import importlib.util
from pathlib import Path
import sys
import wave

import numpy as np
from moviepy import AudioClip, afx

HERE = Path(__file__).resolve().parent
RATE, DURATION = 16000, 1.6
spec = importlib.util.spec_from_file_location("baseline_stereo_volume", HERE / "baseline_effect.py")
baseline = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = baseline
spec.loader.exec_module(baseline)


def tone(t):
    t = np.asarray(t)
    fade = np.clip(np.minimum(t / 0.02, (DURATION - t) / 0.02), 0, 1)
    return 0.12 * fade[..., None] * np.stack(
        [np.sin(2 * np.pi * 440 * t), np.sin(2 * np.pi * 880 * t)], axis=-1
    )


source = AudioClip(tone, duration=DURATION, fps=RATE)
times = np.arange(int(RATE * DURATION)) / RATE
expected_right = source.get_frame(times)[:, 1]
for label, effect in (("before", baseline.MultiplyStereoVolume), ("after", afx.MultiplyStereoVolume)):
    clip = source.with_effects([effect(left=0, right=1)])
    samples = np.vstack([clip.get_frame(np.array([t])) for t in times])
    left, right = np.sqrt(np.mean(samples ** 2, axis=0))
    print(f"{label}: shape={samples.shape}, left RMS={left:.5f}, right RMS={right:.5f}")
    pcm = (samples * 32767).astype("<i2")
    with wave.open(str(HERE / f"reproduced-{label}.wav"), "wb") as out:
        out.setnchannels(2)
        out.setsampwidth(2)
        out.setframerate(RATE)
        out.writeframes(pcm.tobytes())
    if label == "before":
        np.testing.assert_array_equal(samples, 0)
    else:
        np.testing.assert_array_equal(samples[:, 0], 0)
        np.testing.assert_allclose(samples[:, 1], expected_right)
