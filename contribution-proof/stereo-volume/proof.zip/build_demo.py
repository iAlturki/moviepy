"""Generate privacy-safe, executable evidence from actual MoviePy output.

Only synthetic 440/880 Hz tones are used. Both implementations process the same
samples. WAV files are written with Python's wave module; the MP4 simply combines
those PCM outputs with a labelled data visualization.
"""
import base64
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import wave

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from moviepy import AudioClip, afx

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
OUT = HERE / "share"
OUT.mkdir(exist_ok=True)
RATE, DURATION = 16000, 1.6
COUNT = int(RATE * DURATION)
BASE = "211e4b15f6ce4f34a6a9efbfff40590e43a68f77"

spec = importlib.util.spec_from_file_location("original_stereo_volume", HERE / "baseline_effect.py")
baseline = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = baseline
spec.loader.exec_module(baseline)


def tone(t):
    t = np.asarray(t)
    fade = np.clip(np.minimum(t / 0.02, (DURATION - t) / 0.02), 0, 1)
    return 0.12 * fade[..., None] * np.stack(
        [np.sin(2 * np.pi * 440 * t), np.sin(2 * np.pi * 880 * t)], axis=-1
    )


source = AudioClip(tone, duration=DURATION, fps=RATE)
times = np.arange(COUNT) / RATE
reference = source.get_frame(times)


def process(effect, size):
    clip = source.with_effects([effect(left=0, right=1)])
    return np.vstack([clip.get_frame(times[i:i + size]) for i in range(0, COUNT, size)])


outputs = {"reference": reference}
for size in (1, 256):
    outputs[f"before-{size}"] = process(baseline.MultiplyStereoVolume, size)
    outputs[f"after-{size}"] = process(afx.MultiplyStereoVolume, size)
np.testing.assert_allclose(outputs["after-1"], outputs["after-256"])
np.testing.assert_array_equal(outputs["after-1"][:, 0], 0)
np.testing.assert_allclose(outputs["after-1"][:, 1], reference[:, 1])
np.testing.assert_array_equal(outputs["before-1"], 0)


def write_wave(path, data):
    pcm = (np.clip(data, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as stream:
        stream.setnchannels(2)
        stream.setsampwidth(2)
        stream.setframerate(RATE)
        stream.writeframes(pcm.tobytes())


report = {"upstream": BASE, "sample_rate": RATE, "samples": COUNT,
          "duration_seconds": DURATION, "data_source": "synthetic sine waves",
          "requested_gains": {"left": 0, "right": 1}, "cases": {}}
for name, values in outputs.items():
    write_wave(OUT / (name + ".wav"), values)
    report["cases"][name] = {
        "shape": list(values.shape),
        "rms_left": float(np.sqrt(np.mean(values[:, 0] ** 2))),
        "rms_right": float(np.sqrt(np.mean(values[:, 1] ** 2))),
    }
scalar = source.with_effects([baseline.MultiplyStereoVolume(left=0, right=1)])
try:
    scalar.get_frame(0.0125)
    report["scalar_before"] = "unexpected success"
except Exception as error:
    report["scalar_before"] = type(error).__name__
report["scalar_after"] = source.with_effects([afx.MultiplyStereoVolume(left=0, right=1)]).get_frame(0.0125).tolist()
(OUT / "results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

FONT_DIR = Path("C:/Windows/Fonts")


def font(size, bold=False):
    return ImageFont.truetype(str(FONT_DIR / ("segoeuib.ttf" if bold else "segoeui.ttf")), size)


def draw_frame(progress=None, active=None):
    img = Image.new("RGB", (960, 600), "#0d1117")
    draw = ImageDraw.Draw(img)
    draw.text((38, 26), "MoviePy  /  stereo volume", font=font(32, True), fill="#f0f6fc")
    draw.text((40, 76), "Requested: mute LEFT, keep RIGHT  |  one-sample batches", font=font(21), fill="#9da7b5")
    for i, (title, name, color, outcome) in enumerate([
        ("BEFORE", "before-1", "#ff7b72", "Both channels become silent"),
        ("AFTER", "after-1", "#3fd69f", "Right channel stays audible"),
    ]):
        x = 38 + i * 466
        border = color if active == i else "#303b49"
        draw.rounded_rectangle((x, 127, x + 448, 477), radius=20, fill="#151b24", outline=border, width=3)
        draw.text((x + 23, 147), title, font=font(22, True), fill=color)
        draw.text((x + 23, 191), "RIGHT channel  /  880 Hz", font=font(18), fill="#c4ceda")
        draw.line((x + 24, 302, x + 423, 302), fill="#394757", width=1)
        sample = outputs[name][160:320, 1]
        points = [(x + 25 + n * 396 / (len(sample) - 1), 302 - value * 480) for n, value in enumerate(sample)]
        draw.line(points, fill=color, width=3)
        draw.text((x + 23, 385), outcome, font=font(21, True), fill="#e6edf3")
        rms = report["cases"][name]["rms_right"]
        draw.text((x + 23, 424), f"Measured RMS: {rms:.5f}", font=font(18), fill="#9da7b5")
        if progress is not None and active == i:
            draw.rounded_rectangle((x + 24, 459, x + 423, 465), radius=3, fill="#303b49")
            if progress > 0:
                draw.rounded_rectangle((x + 24, 459, x + 24 + 399 * progress, 465), radius=3, fill=color)
    draw.text((40, 505), "Actual output: MultiplyStereoVolume(left=0, right=1)", font=font(19), fill="#c4ceda")
    draw.text((40, 543), "Synthetic tones only  /  No personal media  /  Waveform view: 10 ms", font=font(17), fill="#7c8b9d")
    return img


draw_frame().save(OUT / "before-after.png", optimize=True)

# A 4-second 25 fps loop; every generated frame is preserved.
gif_frames = [draw_frame((i % 50) / 49, 0 if i < 50 else 1) for i in range(100)]
gif_frames[0].save(OUT / "before-after.gif", save_all=True, append_images=gif_frames[1:],
                   duration=40, loop=0, optimize=True)

ffmpeg = shutil.which("ffmpeg")
gap = np.zeros((int(0.4 * RATE), 2))
soundtrack = np.vstack([outputs["before-1"], gap, outputs["after-1"], gap])
write_wave(OUT / "comparison.wav", soundtrack)
command = [ffmpeg, "-y", "-loglevel", "error", "-f", "rawvideo", "-pixel_format", "rgb24",
           "-video_size", "960x600", "-framerate", "30", "-i", "pipe:0", "-i", str(OUT / "comparison.wav"),
           "-map_metadata", "-1", "-c:v", "libx264", "-preset", "medium", "-crf", "23",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart",
           "-shortest", str(OUT / "before-after.mp4")]
encoder = subprocess.Popen(command, stdin=subprocess.PIPE)
for i in range(120):
    active = 0 if i < 60 else 1
    encoder.stdin.write(draw_frame(min((i % 60) / 48, 1), active).tobytes())
encoder.stdin.close()
if encoder.wait() != 0:
    raise SystemExit("Video encoding failed")

audio = {name: "data:audio/wav;base64," + base64.b64encode((OUT / (name + ".wav")).read_bytes()).decode()
         for name in outputs}
template = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MoviePy stereo-volume proof</title><style>
*{box-sizing:border-box}body{margin:0;background:#0d1117;color:#e6edf3;font:17px system-ui,sans-serif}main{max-width:960px;margin:40px auto;padding:24px}h1{font-size:34px}p{line-height:1.65;color:#aab8c7}code{color:#74dcaf}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.card{border:1px solid #354153;border-radius:20px;padding:24px;background:#151b24}h2{margin-top:0}.before{color:#ff8c83}.after{color:#46dba5}audio{width:100%;margin:14px 0}select{font:inherit;background:#202a38;color:#fff;border:1px solid #53657d;border-radius:10px;padding:10px}pre{white-space:pre-wrap;background:#151b24;padding:20px;border-radius:14px;font-size:15px}small{color:#91a0b4}@media(max-width:650px){.grid{grid-template-columns:1fr}main{margin:0 auto;padding:20px}h1{font-size:27px}}
</style><main><h1>Hear the stereo-volume fix</h1><p>The same generated 440/880 Hz stereo tone is passed through the original and fixed MoviePy effect. Requested gains: <code>left=0, right=1</code>. Both WAV files contain the actual returned samples, with no personal recordings or external media.</p>
<label>Samples passed to each call: <select id="batch"><option value="1">1 sample — reproduces the bug</option><option value="256">256 samples — control case</option></select></label>
<p id="explanation"></p><div class="grid"><section class="card"><h2 class="before">Before</h2><audio id="before" controls preload="none"></audio><small id="beforeStats"></small></section><section class="card"><h2 class="after">After</h2><audio id="after" controls preload="none"></audio><small id="afterStats"></small></section></div>
<h2>Original generated signal</h2><audio id="reference" controls preload="none"></audio><p>Keep your normal comfortable volume. In the failing case, the original effect makes both channels silent; the fix retains the 880 Hz right channel. The 256-sample control works in both versions.</p>
<h2>What changed</h2><p>The original effect confuses batch length with channel count. The fix uses the clip's declared channel count, broadcasts gains over the channel axis, and avoids changing shared source samples.</p><pre id="facts"></pre><small>Self-contained evidence file. No external scripts, network requests, trackers, account data or personal media.</small></main><script>
const clips=__AUDIO__,results=__RESULTS__;
function update(){const n=document.getElementById('batch').value;for(const side of ['before','after']){const player=document.getElementById(side);player.pause();player.src=clips[side+'-'+n];const m=results.cases[side+'-'+n];document.getElementById(side+'Stats').textContent='RMS · left '+m.rms_left.toFixed(5)+' / right '+m.rms_right.toFixed(5)}document.getElementById('explanation').textContent=n==='1'?'Bug reproduction: original output is silent; fixed output preserves the right tone.':'Control: larger batches preserve the right tone in both implementations.';document.getElementById('facts').textContent=JSON.stringify({upstream:results.upstream,sample_rate:results.sample_rate,samples:results.samples,gains:results.requested_gains,scalar_before:results.scalar_before,scalar_after:results.scalar_after},null,2)}
document.getElementById('reference').src=clips.reference;document.getElementById('batch').addEventListener('change',update);document.querySelectorAll('audio').forEach(a=>a.addEventListener('play',()=>document.querySelectorAll('audio').forEach(b=>{if(a!==b)b.pause()})));update();
</script></html>'''
(OUT / "interactive-demo.html").write_text(template.replace("__AUDIO__", json.dumps(audio)).replace("__RESULTS__", json.dumps(report)), encoding="utf-8")
print(json.dumps({"report": report, "assets": {p.name: p.stat().st_size for p in OUT.iterdir()}}, indent=2))
